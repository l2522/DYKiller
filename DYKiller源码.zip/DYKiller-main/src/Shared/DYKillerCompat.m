// DYKillerCompat.m
// 提供 compiler-rt 运行时符号 ___isPlatformVersionAtLeast（Mach-O 名）。
// @available() 会让 clang 引用该符号；本机交叉工具链未链接 libclang_rt，
// 若留成 undefined，flat-namespace 方式 dlopen 时会因找不到符号而加载失败。
#import <Foundation/Foundation.h>

int __isPlatformVersionAtLeast(unsigned major, unsigned minor, unsigned subminor,
                               unsigned platform) {
    // 只服务 iOS（platform 0）；其他平台场景保守返回 1。
    if (platform != 0) return 1;
    NSOperatingSystemVersion v = NSProcessInfo.processInfo.operatingSystemVersion;
    if (v.majorVersion > major) return 1;
    if (v.majorVersion < major) return 0;
    if (v.minorVersion > minor) return 1;
    if (v.minorVersion < minor) return 0;
    return v.patchVersion >= subminor;
}
